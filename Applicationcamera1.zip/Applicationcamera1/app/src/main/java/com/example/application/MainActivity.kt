package com.example.application

import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// 裁剪比例枚举
enum class CropRatio(val width: Int, val height: Int, val displayName: String) {
    FREE(0, 0, "自由"),
    SQUARE(1, 1, "1:1"),
    PORTRAIT_4_3(3, 4, "3:4"),
    LANDSCAPE_4_3(4, 3, "4:3"),
    PORTRAIT_9_16(9, 16, "9:16"),
    LANDSCAPE_16_9(16, 9, "16:9")
}

// 裁剪框的触摸状态枚举
enum class CropTouchState {
    NONE,
    MOVE,
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT,
    TOP,
    BOTTOM,
    LEFT,
    RIGHT
}

// 文字水印数据类
data class TextWatermark(
    var text: String = "",
    var x: Float = 0f,
    var y: Float = 0f,
    var textSize: Float = 30f,
    var textColor: Int = android.graphics.Color.WHITE, // 默认白色，可选择：红，黄，蓝，绿，青、蓝、紫、黑、白、灰
    var alpha: Int = 255, // 透明度：0-255，默认不透明
    var fontFamily: String = "宋体", // 字体类型，默认宋体
    var isDragging: Boolean = false,
    var rotation: Float = 0f // 旋转角度，0-360度
)

// 字体映射工具函数
fun getFontFamilyTypeface(fontFamilyName: String): Typeface {
    return when (fontFamilyName) {
        "宋体" -> Typeface.SERIF
        "楷体" -> Typeface.create("楷体", Typeface.NORMAL)
        "微软雅黑" -> Typeface.SANS_SERIF
        "新罗马" -> Typeface.create("Times New Roman", Typeface.NORMAL)
        else -> Typeface.DEFAULT
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var imageView: ImageView
    private lateinit var btnSelectImage: Button
    private lateinit var btnCrop: Button
    private lateinit var btnReset: Button
    private lateinit var cropOverlay: View
    private lateinit var btnRatio: Button
    private lateinit var btnEdit: Button
    private lateinit var btnSave: Button

    private var originalBitmap: Bitmap? = null
    private var currentBitmap: Bitmap? = null
    private var tempBitmap: Bitmap? = null // 用于实时预览亮度和对比度调节
    private var scaleGestureDetector: ScaleGestureDetector? = null
    private var matrix = Matrix()
    private var scale = 1f
    private var lastScaleX = 1f
    private var lastScaleY = 1f
    private var translateX = 0f
    private var translateY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var inCropMode = false
    private var inTextEditMode = false
    private val textWatermarks = mutableListOf<TextWatermark>()
    private var selectedWatermark: TextWatermark? = null
    // 用于双指缩放和旋转的变量
    private var lastDistance = 0f
    private var lastAngle = 0f
    private var isScaling = false
    private var isRotating = false

    // 裁剪比例相关变量
    private var currentRatio: CropRatio = CropRatio.FREE
    private var ratioIndex = 0
    private val cropRatios = listOf(
        CropRatio.FREE,
        CropRatio.SQUARE,
        CropRatio.LANDSCAPE_4_3,
        CropRatio.LANDSCAPE_16_9,
        CropRatio.PORTRAIT_4_3,
        CropRatio.PORTRAIT_9_16
    )
    // 裁剪框触摸处理变量
    private var cropTouchState = CropTouchState.NONE
    private val handleSize = 40f // 拖拽手柄的大小
    private val minCropSize = 100f // 最小裁剪框大小

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val imageUri: Uri? = data?.data
            try {
                originalBitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
                currentBitmap = originalBitmap?.copy(Bitmap.Config.ARGB_8888, true)
                imageView.setImageBitmap(currentBitmap)

                // 重置变换矩阵
                resetTransformations()

                // 启用按钮
                btnCrop.isEnabled = true
                btnReset.isEnabled = true
                btnEdit.isEnabled = true
                btnSave.isEnabled = true

                // 退出裁剪模式
                exitCropMode()

            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "加载图片失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 保存图片权限启动器
    private val savePermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) {
            currentBitmap?.let { bitmap ->
                saveImageToGallery(bitmap)
            }
        } else {
            Toast.makeText(this, "需要存储权限来保存图片", Toast.LENGTH_SHORT).show()
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            pickImage()
        } else {
            Toast.makeText(this, "需要权限来选择图片", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initViews()
        setupListeners()
    }

    private fun initViews() {
        imageView = findViewById(R.id.image_view)
        btnSelectImage = findViewById(R.id.btn_select_image)
        btnCrop = findViewById(R.id.btn_crop)
        btnReset = findViewById(R.id.btn_reset)
        cropOverlay = findViewById(R.id.crop_overlay)
        btnRatio = findViewById(R.id.btn_ratio)
        btnEdit = findViewById(R.id.btn_edit)
        btnSave = findViewById(R.id.btn_save)

        scaleGestureDetector = ScaleGestureDetector(this, ScaleListener())

        // 初始禁用按钮
        btnCrop.isEnabled = false
        btnReset.isEnabled = false
        btnRatio.isEnabled = false
        btnEdit.isEnabled = false
        btnSave.isEnabled = false
    }

    private fun setupListeners() {
        btnSelectImage.setOnClickListener {
            checkPermissionAndPickImage()
        }

        btnCrop.setOnClickListener {
            if (inCropMode) {
                performCrop()
            } else {
                enterCropMode()
            }
        }

        btnReset.setOnClickListener {
            resetImage()
        }

        btnRatio.setOnClickListener {
            cycleCropRatio()
        }

        btnEdit.setOnClickListener {
            showEditMenu(it)
        }

        btnSave.setOnClickListener {
            checkSavePermissionAndSaveImage()
        }

        imageView.setOnTouchListener { _, event ->
            if (inCropMode) {
                handleCropOverlayTouch(event)
            } else if (inTextEditMode) {
                handleTextWatermarkTouch(event)
            } else {
                handleImageTouch(event)
            }
            true
        }

        // 裁剪框触摸事件
        cropOverlay.setOnTouchListener { _, event ->
            handleCropOverlayTouch(event)
            true
        }
    }

    private fun checkPermissionAndPickImage() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_IMAGES
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            pickImage()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        pickImageLauncher.launch(intent)
    }

    private fun resetTransformations() {
        matrix = Matrix()
        scale = 1f
        lastScaleX = 1f
        lastScaleY = 1f
        translateX = 0f
        translateY = 0f
        imageView.imageMatrix = matrix
    }

    private fun enterCropMode() {
        inCropMode = true
        cropOverlay.visibility = View.VISIBLE
        btnCrop.text = "确认裁剪"
        btnRatio.isEnabled = true
        btnRatio.text = currentRatio.displayName

        // 初始化裁剪框大小
        adjustCropOverlaySize()
    }

    private fun exitCropMode() {
        inCropMode = false
        cropOverlay.visibility = View.GONE
        btnCrop.text = "裁剪"
        btnRatio.isEnabled = false
        cropTouchState = CropTouchState.NONE
    }

    private fun exitTextEditMode() {
        inTextEditMode = false
        selectedWatermark = null
    }

    private fun performCrop() {
        if (currentBitmap == null) return

        try {
            // 获取裁剪区域的位置
            val cropRect = Rect()
            cropOverlay.getDrawingRect(cropRect)
            val location = IntArray(2)
            cropOverlay.getLocationOnScreen(location)

            val imageLocation = IntArray(2)
            imageView.getLocationOnScreen(imageLocation)

            // 计算相对位置和缩放比例
            val x = (location[0] - imageLocation[0] + cropRect.left) / scale
            val y = (location[1] - imageLocation[1] + cropRect.top) / scale
            val width = cropRect.width() / scale
            val height = cropRect.height() / scale

            // 确保裁剪区域在图片范围内
            val safeX = maxOf(0f, minOf(x, currentBitmap!!.width - width))
            val safeY = maxOf(0f, minOf(y, currentBitmap!!.height - height))
            val safeWidth = minOf(width, currentBitmap!!.width - safeX)
            val safeHeight = minOf(height, currentBitmap!!.height - safeY)

            // 执行裁剪
            val croppedBitmap = Bitmap.createBitmap(
                currentBitmap!!,
                safeX.toInt(),
                safeY.toInt(),
                safeWidth.toInt(),
                safeHeight.toInt()
            )

            // 更新图片
            currentBitmap = croppedBitmap
            imageView.setImageBitmap(currentBitmap)

            // 重置变换
            resetTransformations()
            exitCropMode()

            Toast.makeText(this, "裁剪成功", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "裁剪失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 检查保存权限并保存图片
    private fun checkSavePermissionAndSaveImage() {
        // 对于Android 10及以上版本，使用MediaStore API保存图片不需要WRITE_EXTERNAL_STORAGE权限
        // 但在Android 9及以下版本仍需要该权限
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val permission = android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                currentBitmap?.let { bitmap ->
                    saveImageToGallery(bitmap)
                }
            } else {
                savePermissionLauncher.launch(permission)
            }
        } else {
            // Android 10及以上版本可以直接保存，无需额外权限
            currentBitmap?.let { bitmap ->
                saveImageToGallery(bitmap)
            }
        }
    }

    // 保存图片到相册
    private fun saveImageToGallery(bitmap: Bitmap): Boolean {
        return try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val imageFileName = "CROPPED_$timestamp.jpg"

            var fos: OutputStream? = null
            var imageUri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10及以上使用MediaStore API
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, imageFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                }

                val resolver = contentResolver
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                fos = imageUri?.let { resolver.openOutputStream(it) }
            } else {
                // Android 9及以下使用传统文件存储
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val imageFile = File(imagesDir, imageFileName)
                fos = FileOutputStream(imageFile)
                imageUri = Uri.fromFile(imageFile)
            }

            if (fos != null) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos)
                fos.flush()
                fos.close()

                // 通知图库更新
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, imageUri)
                    sendBroadcast(mediaScanIntent)
                }

                Toast.makeText(this, "图片已保存到相册", Toast.LENGTH_SHORT).show()
                true
            } else {
                throw Exception("无法创建文件输出流")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "保存图片失败: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    // 切换裁剪比例
    private fun cycleCropRatio() {
        ratioIndex = (ratioIndex + 1) % cropRatios.size
        currentRatio = cropRatios[ratioIndex]
        btnRatio.text = currentRatio.displayName
        adjustCropOverlaySize()
    }

    // 根据当前选择的比例调整裁剪框大小
    private fun adjustCropOverlaySize() {
        val container = findViewById<View>(R.id.image_container)
        val containerWidth = container.width.toFloat()
        val containerHeight = container.height.toFloat()

        val params = cropOverlay.layoutParams as ConstraintLayout.LayoutParams

        // 重置约束，确保裁剪框居中
        params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
        params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
        params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
        params.marginStart = 0
        params.topMargin = 0

        if (currentRatio == CropRatio.FREE) {
            // 自由裁剪模式，使用默认大小
            params.width = 280
            params.height = 280
        } else {
            // 固定比例模式
            val ratio = currentRatio.width.toFloat() / currentRatio.height.toFloat()

            // 根据容器大小和比例计算裁剪框大小
            val maxSize = minOf(containerWidth * 0.8f, containerHeight * 0.8f)

            if (ratio >= 1) { // 横向比例
                params.width = maxSize.toInt()
                params.height = (maxSize / ratio).toInt()
            } else { // 纵向比例
                params.height = maxSize.toInt()
                params.width = (maxSize * ratio).toInt()
            }
        }

        // 确保裁剪框不小于最小尺寸
        params.width = maxOf(params.width, minCropSize.toInt())
        params.height = maxOf(params.height, minCropSize.toInt())

        cropOverlay.layoutParams = params

        // 强制重新布局，确保裁剪框正确显示
        cropOverlay.requestLayout()
    }

    // 处理裁剪框的触摸事件
    private fun handleCropOverlayTouch(event: MotionEvent): Boolean {
        val cropRect = Rect()
        cropOverlay.getDrawingRect(cropRect)
        val location = IntArray(2)
        cropOverlay.getLocationOnScreen(location)

        val touchX = event.rawX - location[0]
        val touchY = event.rawY - location[1]

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                cropTouchState = determineTouchState(touchX, touchY, cropRect)
                lastTouchX = touchX
                lastTouchY = touchY
            }

            MotionEvent.ACTION_MOVE -> {
                if (cropTouchState != CropTouchState.NONE) {
                    updateCropOverlaySizeAndPosition(touchX, touchY, cropRect)
                    lastTouchX = touchX
                    lastTouchY = touchY
                }
            }

            MotionEvent.ACTION_UP -> {
                cropTouchState = CropTouchState.NONE
            }
        }

        return true
    }

    // 确定触摸点在裁剪框上的位置
    private fun determineTouchState(touchX: Float, touchY: Float, rect: Rect): CropTouchState {
        val leftEdge = touchX < handleSize
        val rightEdge = touchX > rect.width() - handleSize
        val topEdge = touchY < handleSize
        val bottomEdge = touchY > rect.height() - handleSize

        return when {
            leftEdge && topEdge -> CropTouchState.TOP_LEFT
            rightEdge && topEdge -> CropTouchState.TOP_RIGHT
            leftEdge && bottomEdge -> CropTouchState.BOTTOM_LEFT
            rightEdge && bottomEdge -> CropTouchState.BOTTOM_RIGHT
            topEdge -> CropTouchState.TOP
            bottomEdge -> CropTouchState.BOTTOM
            leftEdge -> CropTouchState.LEFT
            rightEdge -> CropTouchState.RIGHT
            rect.contains(touchX.toInt(), touchY.toInt()) -> CropTouchState.MOVE
            else -> CropTouchState.NONE
        }
    }

    // 更新裁剪框的大小和位置
    private fun updateCropOverlaySizeAndPosition(touchX: Float, touchY: Float, rect: Rect) {
        val params = cropOverlay.layoutParams as ConstraintLayout.LayoutParams
        val container = findViewById<View>(R.id.image_container)
        val dx = touchX - lastTouchX
        val dy = touchY - lastTouchY

        when (cropTouchState) {
            CropTouchState.MOVE -> {
                // 移动裁剪框
                // 移除所有居中约束
                params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
                params.endToEnd = ConstraintLayout.LayoutParams.UNSET
                params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
                params.bottomToBottom = ConstraintLayout.LayoutParams.UNSET

                // 使用当前margin作为基础，加上移动的增量
                var newMarginStart = params.marginStart + dx.toInt()
                var newTopMargin = params.topMargin + dy.toInt()

                // 限制在容器范围内
                newMarginStart = maxOf(0, minOf(newMarginStart, container.width - params.width))
                newTopMargin = maxOf(0, minOf(newTopMargin, container.height - params.height))

                // 设置新的margin
                params.marginStart = newMarginStart
                params.topMargin = newTopMargin

                cropOverlay.layoutParams = params
            }

            CropTouchState.TOP_LEFT -> {
                adjustCropSize(-dx, -dy, true, true, params)
            }

            CropTouchState.TOP_RIGHT -> {
                adjustCropSize(dx, -dy, false, true, params)
            }

            CropTouchState.BOTTOM_LEFT -> {
                adjustCropSize(-dx, dy, true, false, params)
            }

            CropTouchState.BOTTOM_RIGHT -> {
                adjustCropSize(dx, dy, false, false, params)
            }

            CropTouchState.TOP -> {
                adjustCropSize(0f, -dy, false, true, params)
            }

            CropTouchState.BOTTOM -> {
                adjustCropSize(0f, dy, false, false, params)
            }

            CropTouchState.LEFT -> {
                adjustCropSize(-dx, 0f, true, false, params)
            }

            CropTouchState.RIGHT -> {
                adjustCropSize(dx, 0f, false, false, params)
            }

            else -> {}
        }
    }

    // 调整裁剪框大小，同时保持比例
    private fun adjustCropSize(deltaWidth: Float, deltaHeight: Float, isLeft: Boolean, isTop: Boolean, params: ConstraintLayout.LayoutParams) {
        var newWidth = params.width + deltaWidth.toInt()
        var newHeight = params.height + deltaHeight.toInt()

        // 保持比例（如果不是自由裁剪）
        if (currentRatio != CropRatio.FREE) {
            val aspectRatio = currentRatio.width.toFloat() / currentRatio.height.toFloat()

            // 根据拖动方向决定以哪个维度为准
            if (Math.abs(deltaWidth) > Math.abs(deltaHeight)) {
                // 宽度变化为主
                newWidth = maxOf(minCropSize.toInt(), newWidth)
                newHeight = (newWidth / aspectRatio).toInt()
            } else {
                // 高度变化为主
                newHeight = maxOf(minCropSize.toInt(), newHeight)
                newWidth = (newHeight * aspectRatio).toInt()
            }
        } else {
            // 自由裁剪，单独限制宽度和高度
            newWidth = maxOf(minCropSize.toInt(), newWidth)
            newHeight = maxOf(minCropSize.toInt(), newHeight)
        }

        // 确保裁剪框不超出容器大小的限制
        val container = findViewById<View>(R.id.image_container)
        newWidth = minOf(newWidth, (container.width * 0.9f).toInt())
        newHeight = minOf(newHeight, (container.height * 0.9f).toInt())

        params.width = newWidth
        params.height = newHeight
        cropOverlay.layoutParams = params
    }

    private fun resetImage() {
        if (originalBitmap != null) {
            currentBitmap = originalBitmap?.copy(Bitmap.Config.ARGB_8888, true)
            imageView.setImageBitmap(currentBitmap)
            resetTransformations()
            exitCropMode()
            exitTextEditMode()
            textWatermarks.clear()
            Toast.makeText(this, "图片已重置", Toast.LENGTH_SHORT).show()
        }
    }

    // 显示编辑菜单
    private fun showEditMenu(view: View) {
        val popupMenu = androidx.appcompat.widget.PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.edit_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_brightness_contrast -> {
                    showBrightnessContrastDialog()
                    true
                }
                R.id.menu_rotate_clockwise_90 -> {
                    rotateImageClockwise90()
                    true
                }
                R.id.menu_rotate_counterclockwise_90 -> {
                    rotateImageCounterClockwise90()
                    true
                }
                R.id.menu_rotate_180 -> {
                    rotateImage180()
                    true
                }
                R.id.menu_flip_horizontal -> {
                    flipImageHorizontal()
                    true
                }
                R.id.menu_flip_vertical -> {
                    flipImageVertical()
                    true
                }
                R.id.menu_add_text -> {
                    showTextEditorDialog()
                    true
                }
                else -> false
            }
        }

        popupMenu.show()
    }

    // 显示文字编辑对话框
    private fun showTextEditorDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_text_editor, null)
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("添加文字")
            .setView(dialogView)
        
        val dialog = builder.create()
        
        // 获取控件
        val editTextContent = dialogView.findViewById<EditText>(R.id.edit_text_content)
        val btnCancel = dialogView.findViewById<Button>(R.id.btn_cancel_text)
        val btnApply = dialogView.findViewById<Button>(R.id.btn_apply_text)
        
        // 样式选择控件
        val spinnerFontFamily = dialogView.findViewById<Spinner>(R.id.spinner_font_family)
        val seekbarFontSize = dialogView.findViewById<SeekBar>(R.id.seekbar_font_size)
        val tvFontSize = dialogView.findViewById<TextView>(R.id.tv_font_size)
        val seekbarAlpha = dialogView.findViewById<SeekBar>(R.id.seekbar_alpha)
        val tvAlphaValue = dialogView.findViewById<TextView>(R.id.tv_alpha_value)
        
        // 颜色按钮
        val btnColorWhite = dialogView.findViewById<Button>(R.id.btn_color_white)
        val btnColorBlack = dialogView.findViewById<Button>(R.id.btn_color_black)
        val btnColorRed = dialogView.findViewById<Button>(R.id.btn_color_red)
        val btnColorGreen = dialogView.findViewById<Button>(R.id.btn_color_green)
        val btnColorBlue = dialogView.findViewById<Button>(R.id.btn_color_blue)
        val btnColorYellow = dialogView.findViewById<Button>(R.id.btn_color_yellow)
        val btnColorCyan = dialogView.findViewById<Button>(R.id.btn_color_cyan)
        val btnColorMagenta = dialogView.findViewById<Button>(R.id.btn_color_magenta)
        val btnColorGray = dialogView.findViewById<Button>(R.id.btn_color_gray)
        val btnColorPink = dialogView.findViewById<Button>(R.id.btn_color_pink)
        
        // 样式变量初始化
        var selectedFontFamily = "宋体" // 默认宋体
        var selectedFontSize = 30f // 默认字号30
        var selectedColor = Color.WHITE // 默认白色
        var selectedAlpha = 100 // 默认透明度100%
        
        // 字体选择监听器
        spinnerFontFamily.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedFontFamily = parent.getItemAtPosition(position).toString()
            }
            
            override fun onNothingSelected(parent: AdapterView<*>) {
                // 默认使用宋体
                selectedFontFamily = "宋体"
            }
        }
        
        // 字号选择监听器
        seekbarFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedFontSize = progress.toFloat()
                tvFontSize.text = progress.toString()
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 透明度选择监听器
        seekbarAlpha.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedAlpha = progress
                tvAlphaValue.text = "${progress}%"
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 颜色选择监听器
        val setSelectedColor = { color: Int ->
            selectedColor = color
            // 打印选择的颜色信息，用于调试
            println("Selected color: $color")
        }
        
        // 确保使用正确的颜色常量，实现10种颜色选择：红，黄，蓝，绿，青、紫、黑、白、灰
        btnColorWhite.setOnClickListener { setSelectedColor(Color.WHITE) }
        btnColorBlack.setOnClickListener { setSelectedColor(Color.BLACK) }
        btnColorRed.setOnClickListener { setSelectedColor(Color.RED) }
        btnColorGreen.setOnClickListener { setSelectedColor(Color.GREEN) }
        btnColorBlue.setOnClickListener { setSelectedColor(Color.BLUE) } // 蓝色
        btnColorYellow.setOnClickListener { setSelectedColor(Color.YELLOW) }
        btnColorCyan.setOnClickListener { setSelectedColor(Color.CYAN) } // 青色
        btnColorMagenta.setOnClickListener { setSelectedColor(Color.MAGENTA) } // 紫色（洋红色）
        btnColorGray.setOnClickListener { setSelectedColor(Color.GRAY) }
        btnColorPink.setOnClickListener { setSelectedColor(Color.DKGRAY) } // 深灰色，确保覆盖10种颜色
        
        // 取消按钮
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        
        // 应用按钮
        btnApply.setOnClickListener {
            val text = editTextContent.text.toString().trim()
            if (text.isNotEmpty()) {
                // 将透明度百分比转换为0-255的范围
                val alphaValue = (selectedAlpha * 255 / 100).coerceIn(0, 255)
                addTextToImage(text, selectedFontFamily, selectedFontSize, selectedColor, alphaValue)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "文字内容不能为空", Toast.LENGTH_SHORT).show()
            }
        }
        
        dialog.show()
    }

    // 添加文字到图片
    private fun addTextToImage(text: String, fontFamily: String, fontSize: Float, color: Int, alpha: Int) {
        if (currentBitmap == null) return
        
        // 验证alpha值有效性（颜色值由Android Color类提供，无需额外验证）
        if (alpha < 0 || alpha > 255) {
            Toast.makeText(this, "透明度参数无效", Toast.LENGTH_SHORT).show()
            return
        }
        
        // 创建新的文字水印，默认放在图片中心
        val centerX = currentBitmap!!.width / 2f
        val centerY = currentBitmap!!.height / 2f
        
        val newWatermark = TextWatermark(
            text = text,
            x = centerX,
            y = centerY,
            textSize = fontSize,
            textColor = color, // 确保颜色正确传递
            alpha = alpha,
            fontFamily = fontFamily
        )
        
        textWatermarks.add(newWatermark)
        inTextEditMode = true
        renderTextWatermarks()
        
        Toast.makeText(this, "点击并拖动文字可以调整位置", Toast.LENGTH_LONG).show()
    }

    // 渲染文字水印
    private fun renderTextWatermarks() {
        if (currentBitmap == null) return
        
        try {
            // 创建一个可编辑的bitmap副本
            val bitmapWithText = currentBitmap!!.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(bitmapWithText)
            
            textWatermarks.forEach { watermark ->
                // 为每个水印创建独立的画笔
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                paint.textSize = watermark.textSize
                
                // 确保正确应用颜色和透明度
                // 先设置基础颜色
                paint.color = watermark.textColor
                // 打印颜色信息用于调试
                println("Rendering text with color: ${watermark.textColor}")
                
                // 然后设置透明度，确保alpha值正确应用
                paint.alpha = watermark.alpha
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                
                // 设置字体，使用字体映射函数
                paint.typeface = getFontFamilyTypeface(watermark.fontFamily)
                
                // 设置文字阴影使其在任何背景下都清晰可见
                paint.setShadowLayer(2f, 1f, 1f, android.graphics.Color.BLACK)
                
                // 处理换行
                val lines = watermark.text.split("\n")
                val lineHeight = paint.descent() - paint.ascent()
                val textHeight = lines.size * lineHeight
                
                // 保存画布状态
                canvas.save()
                
                // 如果有旋转角度，应用旋转变换
                if (watermark.rotation != 0f) {
                    canvas.rotate(watermark.rotation, watermark.x, watermark.y)
                }
                
                lines.forEachIndexed { index, line ->
                    val y = watermark.y - (textHeight / 2) + (index * lineHeight) - paint.ascent()
                    canvas.drawText(line, watermark.x, y, paint)
                }
                
                // 恢复画布状态
                canvas.restore()
            }
            
            // 更新显示
            currentBitmap?.recycle()
            currentBitmap = bitmapWithText
            imageView.setImageBitmap(currentBitmap)
            
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "渲染文字失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 计算两点之间的距离
    private fun getDistance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    // 计算两点之间的角度
    private fun getAngle(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        return Math.toDegrees(Math.atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())).toFloat()
    }

    // 处理文字水印的触摸事件
    private fun handleTextWatermarkTouch(event: MotionEvent): Boolean {
        if (currentBitmap == null) return false
        
        // 检测触摸点数
        val pointerCount = event.pointerCount
        
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // 检查是否点击了文字水印
                selectedWatermark = findWatermarkAtPosition(event.x, event.y)
                if (selectedWatermark != null) {
                    selectedWatermark!!.isDragging = true
                    lastTouchX = event.x
                    lastTouchY = event.y
                    isScaling = false
                    isRotating = false
                    // 显示提示信息
                    Toast.makeText(this, "拖动文字移动位置，双指缩放和旋转", Toast.LENGTH_SHORT).show()
                }
            }
            
            MotionEvent.ACTION_POINTER_DOWN -> {
                // 处理第二个手指按下的情况
                if (selectedWatermark != null && pointerCount == 2) {
                    // 计算初始距离和角度
                    val x1 = event.getX(0)
                    val y1 = event.getY(0)
                    val x2 = event.getX(1)
                    val y2 = event.getY(1)
                    
                    lastDistance = getDistance(x1, y1, x2, y2)
                    lastAngle = getAngle(x1, y1, x2, y2)
                    isScaling = true
                    isRotating = true
                }
            }
            
            MotionEvent.ACTION_MOVE -> {
                if (selectedWatermark != null) {
                    if (pointerCount == 1 && selectedWatermark!!.isDragging && !isScaling && !isRotating) {
                        // 单指拖动 - 优化拖动体验
                        // 计算移动距离
                        val dx = event.x - lastTouchX
                        val dy = event.y - lastTouchY
                        
                        // 更新水印位置 - 不限制在图片范围内，允许完全自由拖动
                        selectedWatermark!!.x += dx
                        selectedWatermark!!.y += dy
                        
                        // 更新触摸点
                        lastTouchX = event.x
                        lastTouchY = event.y
                        
                        // 重新渲染
                        renderTextWatermarks()
                    } else if (pointerCount == 2 && isScaling && isRotating) {
                        val x1 = event.getX(0)
                        val y1 = event.getY(0)
                        val x2 = event.getX(1)
                        val y2 = event.getY(1)
                        
                        // 双指缩放 - 优化缩放体验
                        // 计算当前距离
                        val currentDistance = getDistance(x1, y1, x2, y2)
                        
                        // 计算缩放比例 - 添加平滑缩放系数
                        val scaleFactor = currentDistance / lastDistance
                        
                        // 使用更平滑的缩放算法 - 应用插值以避免突变
                        val targetSize = selectedWatermark!!.textSize * scaleFactor
                        // 添加插值平滑效果
                        selectedWatermark!!.textSize = selectedWatermark!!.textSize + (targetSize - selectedWatermark!!.textSize) * 0.8f
                        
                        // 限制文字大小范围 - 扩展范围以支持更大和更小的文字
                        selectedWatermark!!.textSize = selectedWatermark!!.textSize.coerceIn(5f, 200f)
                        
                        // 更新最后距离
                        lastDistance = currentDistance
                        
                        // 双指旋转 - 优化旋转体验
                        // 计算当前角度
                        val currentAngle = getAngle(x1, y1, x2, y2)
                        
                        // 计算角度变化
                        val angleDiff = currentAngle - lastAngle
                        
                        // 使用插值平滑效果改进旋转体验
                        val targetRotation = selectedWatermark!!.rotation + angleDiff
                        // 应用平滑插值系数
                        selectedWatermark!!.rotation = selectedWatermark!!.rotation + (targetRotation - selectedWatermark!!.rotation) * 0.9f
                        
                        // 确保角度在0-360度范围内
                        selectedWatermark!!.rotation = selectedWatermark!!.rotation % 360
                        if (selectedWatermark!!.rotation < 0) {
                            selectedWatermark!!.rotation += 360
                        }
                        
                        // 更新最后角度
                        lastAngle = currentAngle
                        
                        // 重新渲染
                        renderTextWatermarks()
                    }
                }
            }
            
            MotionEvent.ACTION_POINTER_UP -> {
                // 处理手指抬起的情况
                if (pointerCount == 2) {
                    // 从双指回到单指模式
                    isScaling = false
                    isRotating = false
                }
            }
            
            MotionEvent.ACTION_UP -> {
                // 结束拖拽
                val wasDragging = selectedWatermark?.isDragging == true
                selectedWatermark?.isDragging = false
                isScaling = false
                isRotating = false
                
                // 如果没有拖动，说明是点击操作，显示文字样式选择器
                if (selectedWatermark != null && !wasDragging) {
                    showTextStyleDialog(selectedWatermark!!)
                }
                
                selectedWatermark = null
            }
        }
        
        return true
    }
    
    // 显示文字样式选择器对话框
    private fun showTextStyleDialog(watermark: TextWatermark) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_text_style, null)
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("文字样式设置")
            .setView(dialogView)
        
        val dialog = builder.create()
        
        // 初始化控件
        val radioGroupFont = dialogView.findViewById<RadioGroup>(R.id.radio_group_font)
        val radioFontDefault = dialogView.findViewById<RadioButton>(R.id.radio_font_default)
        val radioFontSerif = dialogView.findViewById<RadioButton>(R.id.radio_font_serif)
        val radioFontSansSerif = dialogView.findViewById<RadioButton>(R.id.radio_font_sans_serif)
        val radioFontMonospace = dialogView.findViewById<RadioButton>(R.id.radio_font_monospace)
        
        val seekBarFontSize = dialogView.findViewById<SeekBar>(R.id.seekbar_font_size)
        val textFontSizeValue = dialogView.findViewById<TextView>(R.id.text_font_size_value)
        
        val seekBarRed = dialogView.findViewById<SeekBar>(R.id.seekbar_red)
        val seekBarGreen = dialogView.findViewById<SeekBar>(R.id.seekbar_green)
        val seekBarBlue = dialogView.findViewById<SeekBar>(R.id.seekbar_blue)
        val textRedValue = dialogView.findViewById<TextView>(R.id.text_red_value)
        val textGreenValue = dialogView.findViewById<TextView>(R.id.text_green_value)
        val textBlueValue = dialogView.findViewById<TextView>(R.id.text_blue_value)
        
        val seekBarAlpha = dialogView.findViewById<SeekBar>(R.id.seekbar_alpha)
        val textAlphaValue = dialogView.findViewById<TextView>(R.id.text_alpha_value)
        
        val textPreview = dialogView.findViewById<TextView>(R.id.text_preview)
        val colorPickerContainer = dialogView.findViewById<LinearLayout>(R.id.color_picker_container)
        
        val btnCancel = dialogView.findViewById<Button>(R.id.btn_cancel_style)
        val btnApply = dialogView.findViewById<Button>(R.id.btn_apply_style)
        
        // 预设颜色数组 - 确保包含用户要求的10种颜色：红，黄，蓝，绿，青、紫、黑、白、灰
        val presetColors = intArrayOf(
            Color.WHITE, Color.BLACK, Color.RED, Color.GREEN, Color.BLUE,
            Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.GRAY, Color.DKGRAY
        )
        
        // 设置预览文字
        textPreview.text = "预览效果"
        
        // 初始化UI状态为当前水印的状态
        // 字体
        when (watermark.fontFamily) {
            "serif" -> radioFontSerif.isChecked = true
            "sans-serif" -> radioFontSansSerif.isChecked = true
            "monospace" -> radioFontMonospace.isChecked = true
            else -> radioFontDefault.isChecked = true
        }
        
        // 字号
        seekBarFontSize.progress = watermark.textSize.toInt()
        textFontSizeValue.text = watermark.textSize.toInt().toString()
        
        // 颜色
        val currentColor = watermark.textColor
        seekBarRed.progress = Color.red(currentColor)
        seekBarGreen.progress = Color.green(currentColor)
        seekBarBlue.progress = Color.blue(currentColor)
        textRedValue.text = Color.red(currentColor).toString()
        textGreenValue.text = Color.green(currentColor).toString()
        textBlueValue.text = Color.blue(currentColor).toString()
        
        // 透明度
        seekBarAlpha.progress = watermark.alpha
        textAlphaValue.text = "${(watermark.alpha * 100 / 255)}%"
        
        // 创建预设颜色选择器
        for (color in presetColors) {
            val colorView = View(this)
            val layoutParams = LinearLayout.LayoutParams(40, 40)
            layoutParams.setMargins(8, 8, 8, 8)
            colorView.layoutParams = layoutParams
            colorView.setBackgroundColor(color)
            colorView.setOnClickListener {
                seekBarRed.progress = Color.red(color)
                seekBarGreen.progress = Color.green(color)
                seekBarBlue.progress = Color.blue(color)
                textRedValue.text = Color.red(color).toString()
                textGreenValue.text = Color.green(color).toString()
                textBlueValue.text = Color.blue(color).toString()
                updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
                    Color.rgb(seekBarRed.progress, seekBarGreen.progress, seekBarBlue.progress),
                    seekBarAlpha.progress)
            }
            colorPickerContainer.addView(colorView)
        }
        
        // 更新预览
        updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
            Color.rgb(seekBarRed.progress, seekBarGreen.progress, seekBarBlue.progress),
            seekBarAlpha.progress)
        
        // 字体选择监听器
        radioGroupFont.setOnCheckedChangeListener { _, _ ->
            updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
                Color.rgb(seekBarRed.progress, seekBarGreen.progress, seekBarBlue.progress),
                seekBarAlpha.progress)
        }
        
        // 字号调节监听器
        seekBarFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textFontSizeValue.text = progress.toString()
                updatePreview(textPreview, radioGroupFont, progress, 
                    Color.rgb(seekBarRed.progress, seekBarGreen.progress, seekBarBlue.progress),
                    seekBarAlpha.progress)
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 红色通道调节监听器
        seekBarRed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textRedValue.text = progress.toString()
                updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
                    Color.rgb(progress, seekBarGreen.progress, seekBarBlue.progress),
                    seekBarAlpha.progress)
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 绿色通道调节监听器
        seekBarGreen.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textGreenValue.text = progress.toString()
                updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
                    Color.rgb(seekBarRed.progress, progress, seekBarBlue.progress),
                    seekBarAlpha.progress)
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 蓝色通道调节监听器
        seekBarBlue.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textBlueValue.text = progress.toString()
                updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
                    Color.rgb(seekBarRed.progress, seekBarGreen.progress, progress),
                    seekBarAlpha.progress)
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 透明度调节监听器
        seekBarAlpha.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textAlphaValue.text = "${(progress * 100 / 255)}%"
                updatePreview(textPreview, radioGroupFont, seekBarFontSize.progress, 
                    Color.rgb(seekBarRed.progress, seekBarGreen.progress, seekBarBlue.progress),
                    progress)
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 取消按钮点击事件
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        
        // 应用按钮点击事件
        btnApply.setOnClickListener {
            // 应用样式设置
            when (radioGroupFont.checkedRadioButtonId) {
                R.id.radio_font_serif -> watermark.fontFamily = "serif"
                R.id.radio_font_sans_serif -> watermark.fontFamily = "sans-serif"
                R.id.radio_font_monospace -> watermark.fontFamily = "monospace"
                else -> watermark.fontFamily = "default"
            }
            
            watermark.textSize = seekBarFontSize.progress.toFloat()
            watermark.textColor = Color.rgb(seekBarRed.progress, seekBarGreen.progress, seekBarBlue.progress)
            watermark.alpha = seekBarAlpha.progress
            
            // 重新渲染文字水印
            renderTextWatermarks()
            
            dialog.dismiss()
        }
        
        dialog.show()
    }
    
    // 更新预览文本样式
    private fun updatePreview(textView: TextView, radioGroup: RadioGroup, fontSize: Int, textColor: Int, alpha: Int) {
        // 设置字体
        when (radioGroup.checkedRadioButtonId) {
            R.id.radio_font_serif -> textView.typeface = Typeface.SERIF
            R.id.radio_font_sans_serif -> textView.typeface = Typeface.SANS_SERIF
            R.id.radio_font_monospace -> textView.typeface = Typeface.MONOSPACE
            else -> textView.typeface = Typeface.DEFAULT
        }
        
        // 设置字号
        textView.textSize = fontSize.toFloat()
        
        // 设置颜色和透明度
        val colorWithAlpha = Color.argb(alpha, Color.red(textColor), Color.green(textColor), Color.blue(textColor))
        textView.setTextColor(colorWithAlpha)
    }

    // 查找指定位置的文字水印
    private fun findWatermarkAtPosition(x: Float, y: Float): TextWatermark? {
        // 反向遍历，优先选择上层水印
        for (i in textWatermarks.lastIndex downTo 0) {
            val watermark = textWatermarks[i]
            val paint = Paint()
            paint.textSize = watermark.textSize
            paint.textAlign = Paint.Align.CENTER
            
            // 计算文字的边界矩形
            val lines = watermark.text.split("\n")
            val lineHeight = paint.descent() - paint.ascent()
            val textHeight = lines.size * lineHeight
            val textWidth = paint.measureText(lines.maxByOrNull { paint.measureText(it) } ?: "")
            
            // 扩大点击区域，方便用户操作
            val clickArea = RectF(
                watermark.x - textWidth / 2 - 20,
                watermark.y - textHeight / 2 - 20,
                watermark.x + textWidth / 2 + 20,
                watermark.y + textHeight / 2 + 20
            )
            
            if (clickArea.contains(x, y)) {
                return watermark
            }
        }
        return null
    }

    // 显示亮度和对比度调节对话框
    private fun showBrightnessContrastDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_brightness_contrast, null)
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("亮度和对比度调节")
            .setView(dialogView)
        
        val dialog = builder.create()
        
        val seekBarBrightness = dialogView.findViewById<android.widget.SeekBar>(R.id.seekbar_brightness)
        val seekBarContrast = dialogView.findViewById<android.widget.SeekBar>(R.id.seekbar_contrast)
        val textBrightnessValue = dialogView.findViewById<android.widget.TextView>(R.id.text_brightness_value)
        val textContrastValue = dialogView.findViewById<android.widget.TextView>(R.id.text_contrast_value)
        val btnReset = dialogView.findViewById<Button>(R.id.btn_reset_adjustments)
        val btnApply = dialogView.findViewById<Button>(R.id.btn_apply_adjustments)
        
        // 保存当前图像用于临时预览
        tempBitmap = currentBitmap?.copy(Bitmap.Config.ARGB_8888, true)
        
        // 设置初始值（SeekBar使用0-200范围表示-100到100的亮度值和-50到150的对比度值）
        seekBarBrightness.progress = 100 // 默认亮度0
        seekBarContrast.progress = 100 // 默认对比度0
        textBrightnessValue.text = "0"
        textContrastValue.text = "0"
        
        // 亮度调节监听器
        seekBarBrightness.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                val brightnessValue = progress - 100 // 将0-200映射到-100到100
                textBrightnessValue.text = brightnessValue.toString()
                
                // 实时应用亮度和对比度调节
                applyBrightnessContrast(brightnessValue, (seekBarContrast.progress - 100).coerceIn(-50, 150))
            }
            
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        
        // 对比度调节监听器
        seekBarContrast.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                val contrastValue = (progress - 100).coerceIn(-50, 150) // 将0-200映射到-50到150
                textContrastValue.text = contrastValue.toString()
                
                // 实时应用亮度和对比度调节
                applyBrightnessContrast((seekBarBrightness.progress - 100), contrastValue)
            }
            
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        
        // 重置按钮点击事件
        btnReset.setOnClickListener {
            seekBarBrightness.progress = 100
            seekBarContrast.progress = 100
            textBrightnessValue.text = "0"
            textContrastValue.text = "0"
            
            // 恢复原始图像
            currentBitmap = tempBitmap?.copy(Bitmap.Config.ARGB_8888, true)
            imageView.setImageBitmap(currentBitmap)
        }
        
        // 应用按钮点击事件
        btnApply.setOnClickListener {
            // 应用更改并关闭对话框
            tempBitmap = null // 释放临时图像
            dialog.dismiss()
        }
        
        dialog.setOnDismissListener {
            // 对话框关闭时，如果没有应用更改，则恢复原始图像
            if (tempBitmap != null) {
                currentBitmap = tempBitmap?.copy(Bitmap.Config.ARGB_8888, true)
                imageView.setImageBitmap(currentBitmap)
                tempBitmap = null // 释放临时图像
            }
        }
        
        dialog.show()
    }
    
    // 应用亮度和对比度调节
    private fun applyBrightnessContrast(brightness: Int, contrast: Int) {
        if (currentBitmap == null || tempBitmap == null) return
        
        try {
            // 优化内存使用：重用之前的bitmap或创建新的
            val adjustedBitmap = if (currentBitmap != null && 
                currentBitmap!!.width == tempBitmap!!.width && 
                currentBitmap!!.height == tempBitmap!!.height) {
                currentBitmap!!
            } else {
                Bitmap.createBitmap(tempBitmap!!.width, tempBitmap!!.height, Bitmap.Config.ARGB_8888)
            }
            
            val canvas = Canvas(adjustedBitmap)
            
            // 创建ColorMatrix来调整亮度和对比度
            val colorMatrix = ColorMatrix()
            
            // 更准确的对比度计算：将-50到150范围映射到0.5到2.5
            val contrastFactor = when {
                contrast < 0 -> 1.0f + (contrast.toFloat() / 200.0f) // -50到0映射到0.75到1.0
                else -> 1.0f + (contrast.toFloat() / 100.0f) // 0到150映射到1.0到2.5
            }
            
            // 先设置对比度
            colorMatrix.setScale(contrastFactor, contrastFactor, contrastFactor, 1f)
            
            // 然后应用亮度调整
            // 亮度值范围：-100到100，将其映射到-255到255的范围
            val brightnessValue = (brightness.toFloat() / 100.0f) * 255.0f
            
            val brightnessMatrix = ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, brightnessValue,
                    0f, 1f, 0f, 0f, brightnessValue,
                    0f, 0f, 1f, 0f, brightnessValue,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            
            // 合并对比度和亮度矩阵
            colorMatrix.postConcat(brightnessMatrix)
            
            // 创建画笔并应用ColorMatrix
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
            
            // 绘制调整后的图像
            canvas.drawBitmap(tempBitmap!!, 0f, 0f, paint)
            
            // 更新显示
            if (adjustedBitmap !== currentBitmap) {
                // 回收旧的bitmap以避免内存泄漏
                currentBitmap?.recycle()
                currentBitmap = adjustedBitmap
            }
            
            imageView.setImageBitmap(currentBitmap)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "调整图像失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 顺时针旋转90度
    private fun rotateImageClockwise90() {
        if (currentBitmap == null) return

        try {
            val matrix = Matrix()
            matrix.postRotate(90f)

            currentBitmap = Bitmap.createBitmap(
                currentBitmap!!,
                0,
                0,
                currentBitmap!!.width,
                currentBitmap!!.height,
                matrix,
                true
            )

            imageView.setImageBitmap(currentBitmap)
            resetTransformations()
            Toast.makeText(this, "已顺时针旋转90°", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "旋转失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 逆时针旋转90度（等同于顺时针旋转270度）
    private fun rotateImageCounterClockwise90() {
        if (currentBitmap == null) return

        try {
            val matrix = Matrix()
            matrix.postRotate(-90f) // 使用负数表示逆时针旋转

            currentBitmap = Bitmap.createBitmap(
                currentBitmap!!,
                0,
                0,
                currentBitmap!!.width,
                currentBitmap!!.height,
                matrix,
                true
            )

            imageView.setImageBitmap(currentBitmap)
            resetTransformations()
            Toast.makeText(this, "已逆时针旋转90°", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "旋转失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 旋转180度
    private fun rotateImage180() {
        if (currentBitmap == null) return

        try {
            val matrix = Matrix()
            matrix.postRotate(180f)

            currentBitmap = Bitmap.createBitmap(
                currentBitmap!!,
                0,
                0,
                currentBitmap!!.width,
                currentBitmap!!.height,
                matrix,
                true
            )

            imageView.setImageBitmap(currentBitmap)
            resetTransformations()
            Toast.makeText(this, "已旋转180°", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "旋转失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 水平翻转
    private fun flipImageHorizontal() {
        if (currentBitmap == null) return

        try {
            val matrix = Matrix()
            matrix.postScale(-1f, 1f) // 水平翻转，X轴缩放因子为-1

            currentBitmap = Bitmap.createBitmap(
                currentBitmap!!,
                0,
                0,
                currentBitmap!!.width,
                currentBitmap!!.height,
                matrix,
                true
            )

            imageView.setImageBitmap(currentBitmap)
            resetTransformations()
            Toast.makeText(this, "已水平翻转", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "翻转失败", Toast.LENGTH_SHORT).show()
        }
    }

    // 垂直翻转
    private fun flipImageVertical() {
        if (currentBitmap == null) return

        try {
            val matrix = Matrix()
            matrix.postScale(1f, -1f) // 垂直翻转，Y轴缩放因子为-1

            currentBitmap = Bitmap.createBitmap(
                currentBitmap!!,
                0,
                0,
                currentBitmap!!.width,
                currentBitmap!!.height,
                matrix,
                true
            )

            imageView.setImageBitmap(currentBitmap)
            resetTransformations()
            Toast.makeText(this, "已垂直翻转", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "翻转失败", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleImageTouch(event: MotionEvent): Boolean {
        scaleGestureDetector?.onTouchEvent(event)

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
            }

            MotionEvent.ACTION_MOVE -> {
                if (scaleGestureDetector?.isInProgress == false) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY

                    translateX += dx
                    translateY += dy

                    updateMatrix()

                    lastTouchX = event.x
                    lastTouchY = event.y
                }
            }
        }

        return true
    }

    private fun updateMatrix() {
        matrix.reset()
        matrix.postScale(scale, scale)
        matrix.postTranslate(translateX, translateY)
        imageView.imageMatrix = matrix
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            lastScaleX = scale
            lastScaleY = scale
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scale = lastScaleX * detector.scaleFactor
            // 限制缩放范围
            scale = maxOf(0.1f, minOf(scale, 10f))
            updateMatrix()
            return true
        }
    }
}
package com.example.application

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/**
 * 图像拼接工具类，支持横向、纵向和网格拼接
 */
class ImageStitcher {
    
    /**
     * 拼接模式枚举
     */
    enum class StitchMode {
        HORIZONTAL,    // 横向拼接
        VERTICAL,      // 纵向拼接
        GRID_2x2       // 2x2网格拼接
    }
    
    /**
     * 拼接图像
     * @param bitmaps 需要拼接的图像列表
     * @param mode 拼接模式
     * @return 拼接后的图像，如果参数无效则返回null
     */
    fun stitchImages(bitmaps: List<Bitmap>, mode: StitchMode): Bitmap? {
        // 验证输入参数
        if (bitmaps.isEmpty() || bitmaps.size > 4) {
            return null
        }
        
        // 根据模式选择对应的拼接方法
        return when (mode) {
            StitchMode.HORIZONTAL -> stitchHorizontal(bitmaps)
            StitchMode.VERTICAL -> stitchVertical(bitmaps)
            StitchMode.GRID_2x2 -> stitchGrid2x2(bitmaps)
        }
    }
    
    /**
     * 横向拼接图像
     * @param bitmaps 需要拼接的图像列表
     * @return 拼接后的图像
     */
    private fun stitchHorizontal(bitmaps: List<Bitmap>): Bitmap {
        // 计算拼接后的宽度和高度
        val totalWidth = bitmaps.sumOf { it.width }
        val maxHeight = bitmaps.maxOf { it.height }
        
        // 创建目标图像
        val resultBitmap = Bitmap.createBitmap(totalWidth, maxHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(resultBitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        
        // 开始拼接
        var currentX = 0
        for (bitmap in bitmaps) {
            // 计算图像居中显示的Y坐标
            val top = (maxHeight - bitmap.height) / 2
            canvas.drawBitmap(bitmap, currentX.toFloat(), top.toFloat(), paint)
            currentX += bitmap.width
        }
        
        return resultBitmap
    }
    
    /**
     * 纵向拼接图像
     * @param bitmaps 需要拼接的图像列表
     * @return 拼接后的图像
     */
    private fun stitchVertical(bitmaps: List<Bitmap>): Bitmap {
        // 计算拼接后的宽度和高度
        val maxWidth = bitmaps.maxOf { it.width }
        val totalHeight = bitmaps.sumOf { it.height }
        
        // 创建目标图像
        val resultBitmap = Bitmap.createBitmap(maxWidth, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(resultBitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        
        // 开始拼接
        var currentY = 0
        for (bitmap in bitmaps) {
            // 计算图像居中显示的X坐标
            val left = (maxWidth - bitmap.width) / 2
            canvas.drawBitmap(bitmap, left.toFloat(), currentY.toFloat(), paint)
            currentY += bitmap.height
        }
        
        return resultBitmap
    }
    
    /**
     * 2x2网格拼接图像
     * @param bitmaps 需要拼接的图像列表，支持1-4张图像
     * @return 拼接后的图像
     */
    private fun stitchGrid2x2(bitmaps: List<Bitmap>): Bitmap {
        // 计算每个单元格的大小
        val cellWidth = bitmaps.maxOf { it.width }
        val cellHeight = bitmaps.maxOf { it.height }
        
        // 确定网格大小
        val cols = if (bitmaps.size <= 2) 2 else 2
        val rows = if (bitmaps.size == 1) 1 else if (bitmaps.size == 2) 1 else 2
        
        // 计算结果图像的大小
        val resultWidth = cellWidth * cols
        val resultHeight = cellHeight * rows
        
        // 创建目标图像
        val resultBitmap = Bitmap.createBitmap(resultWidth, resultHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(resultBitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        
        // 填充白色背景
        canvas.drawColor(Color.WHITE)
        
        // 开始拼接
        for (i in bitmaps.indices) {
            val bitmap = bitmaps[i]
            val row = i / cols
            val col = i % cols
            
            // 计算图像在单元格中居中显示的坐标
            val left = col * cellWidth + (cellWidth - bitmap.width) / 2
            val top = row * cellHeight + (cellHeight - bitmap.height) / 2
            
            canvas.drawBitmap(bitmap, left.toFloat(), top.toFloat(), paint)
        }
        
        return resultBitmap
    }
    
    /**
     * 调整图像大小，使其适应指定的尺寸
     * @param bitmap 原始图像
     * @param targetWidth 目标宽度
     * @param targetHeight 目标高度
     * @return 调整大小后的图像
     */
    fun resizeBitmap(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }
    
    /**
     * 检查图像列表是否有效（支持拼接）
     * @param bitmaps 图像列表
     * @return 是否有效
     */
    fun isValidBitmaps(bitmaps: List<Bitmap>): Boolean {
        return bitmaps.isNotEmpty() && bitmaps.size <= 4 && bitmaps.all { it != null && !it.isRecycled }
    }
}
package com.example.application

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ImageStitchActivity : AppCompatActivity() {
    private lateinit var imageView1: ImageView
    private lateinit var imageView2: ImageView
    private lateinit var imageView3: ImageView
    private lateinit var imageView4: ImageView
    private lateinit var imageViewResult: ImageView
    private lateinit var btnStitch: View
    private lateinit var btnSave: View
    
    private var bitmap1: Bitmap? = null
    private var bitmap2: Bitmap? = null
    private var bitmap3: Bitmap? = null
    private var bitmap4: Bitmap? = null
    private var resultBitmap: Bitmap? = null
    
    private val imageStitcher = ImageStitcher()
    
    // 当前选择的图像位置（用于区分是选择哪张图像）
    private var currentImagePosition = 0
    
    // 图像选择启动器
    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            val data: Intent? = it.data
            val imageUri: Uri? = data?.data
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
                
                // 根据当前选择的位置设置图像
                when (currentImagePosition) {
                    1 -> {
                        bitmap1 = bitmap
                        imageView1.setImageBitmap(bitmap)
                    }
                    2 -> {
                        bitmap2 = bitmap
                        imageView2.setImageBitmap(bitmap)
                    }
                    3 -> {
                        bitmap3 = bitmap
                        imageView3.setImageBitmap(bitmap)
                    }
                    4 -> {
                        bitmap4 = bitmap
                        imageView4.setImageBitmap(bitmap)
                    }
                }
                
                // 启用拼接按钮
                btnStitch.isEnabled = true
                btnSave.isEnabled = false
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "加载图片失败", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    // 保存权限启动器
    private val savePermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) {
            resultBitmap?.let { bitmap ->
                saveImageToGallery(bitmap)
            }
        } else {
            Toast.makeText(this, "需要存储权限来保存图片", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_image_stitch)
        
        initViews()
        setupListeners()
    }
    
    private fun initViews() {
        imageView1 = findViewById(R.id.imageView1)
        imageView2 = findViewById(R.id.imageView2)
        imageView3 = findViewById(R.id.imageView3)
        imageView4 = findViewById(R.id.imageView4)
        imageViewResult = findViewById(R.id.imageViewResult)
        btnStitch = findViewById(R.id.btnStitch)
        btnSave = findViewById(R.id.btnSave)
        
        // 初始状态下拼接按钮禁用
        btnStitch.isEnabled = false
    }
    
    private fun setupListeners() {
        // 拼接按钮点击事件
        btnStitch.setOnClickListener {
            stitchImages()
        }
        
        // 保存按钮点击事件
        btnSave.setOnClickListener {
            checkSavePermissionAndSaveImage()
        }
        
        // 重置按钮状态
        updateButtonStates()
    }
    
    // 选择第一张图像
    fun selectImage1(view: View) {
        currentImagePosition = 1
        pickImage()
    }
    
    // 选择第二张图像
    fun selectImage2(view: View) {
        currentImagePosition = 2
        pickImage()
    }
    
    // 选择第三张图像
    fun selectImage3(view: View) {
        currentImagePosition = 3
        pickImage()
    }
    
    // 选择第四张图像
    fun selectImage4(view: View) {
        currentImagePosition = 4
        pickImage()
    }
    
    private fun pickImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        pickImageLauncher.launch(intent)
    }
    
    private fun stitchImages() {
        // 收集已选择的图像
        val bitmaps = mutableListOf<Bitmap>()
        bitmap1?.let { bitmaps.add(it) }
        bitmap2?.let { bitmaps.add(it) }
        bitmap3?.let { bitmaps.add(it) }
        bitmap4?.let { bitmaps.add(it) }
        
        // 验证图像数量
        if (bitmaps.isEmpty() || bitmaps.size > 4) {
            Toast.makeText(this, "请选择1-4张图像进行拼接", Toast.LENGTH_SHORT).show()
            return
        }
        
        // 检查网格模式的特殊限制
        val radioGrid = findViewById<RadioButton>(R.id.radioGrid)
        if (radioGrid.isChecked && bitmaps.size > 4) {
            Toast.makeText(this, "网格模式最多支持4张图像", Toast.LENGTH_SHORT).show()
            return
        }
        
        // 确定拼接模式
        val mode = when {
            findViewById<RadioButton>(R.id.radioHorizontal).isChecked -> ImageStitcher.StitchMode.HORIZONTAL
            findViewById<RadioButton>(R.id.radioVertical).isChecked -> ImageStitcher.StitchMode.VERTICAL
            else -> ImageStitcher.StitchMode.GRID_2x2
        }
        
        // 执行拼接
        resultBitmap = imageStitcher.stitchImages(bitmaps, mode)
        
        // 显示结果
        if (resultBitmap != null) {
            imageViewResult.setImageBitmap(resultBitmap)
            btnSave.isEnabled = true
            Toast.makeText(this, "拼接成功", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "拼接失败，请重试", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateButtonStates() {
        val hasImages = bitmap1 != null || bitmap2 != null || bitmap3 != null || bitmap4 != null
        btnStitch.isEnabled = hasImages
        btnSave.isEnabled = resultBitmap != null
    }
    
    private fun checkSavePermissionAndSaveImage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveImageToGallery(resultBitmap!!)
        } else {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == 
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
                saveImageToGallery(resultBitmap!!)
            } else {
                savePermissionLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
    }
    
    private fun saveImageToGallery(bitmap: Bitmap): Boolean {
        return try {
            val fileName = "stitched_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.jpg"
            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                }
            }
            
            val resolver = contentResolver
            val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            
            imageUri?.let { uri ->
                resolver.openOutputStream(uri)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                }
                Toast.makeText(this, "图像已保存到相册", Toast.LENGTH_SHORT).show()
                true
            } ?: false
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "保存失败: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }
}